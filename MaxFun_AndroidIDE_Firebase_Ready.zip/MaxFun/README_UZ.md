# MaxFun v1 — AndroidIDE

Bu loyiha MaxFun ijtimoiy media ilovasining ishlaydigan UI + lokal demo bazasi va Firebase integratsiyasi uchun tayyorlangan starter hisoblanadi.

## AndroidIDE'da ishga tushirish
1. ZIPni oching.
2. AndroidIDE → Open Project → `MaxFun` papkasini tanlang.
3. Gradle sync qiling.
4. Firebase ishlashi uchun `app/google-services.json` faylini Firebase Console'dan yuklab, shu joyga qo'ying.
5. Firebase Authentication, Firestore va Storage'ni yoqing.
6. Run ▶️.

## Muhim
`google-services.json` maxfiy konfiguratsiya bo'lgani uchun ZIP ichiga haqiqiy fayl qo'yilmagan. `google-services.json.example` faqat namuna.

## V1 ichidagi bo'limlar
- Home: feed, search, notifications, notes
- Videos: video feed va video tanlash
- Add: video / story / note
- Story: 24 soatlik yoki permanent saqlash rejimi
- Chat: 1-to-1 chat UI
- Groups: guruhlar UI
- Live: live stream UI/entry
- Profile: avatar, bio, videos, streams, followers
- Settings: account, notifications, privacy, appearance, logout
- Online/offline indikatorlari
- Firebase Auth / Firestore / Storage dependency va servis qatlamlari

## Firebase collections tavsiyasi
users/{uid}
videos/{videoId}
stories/{storyId}
notes/{noteId}
chats/{chatId}/messages/{messageId}
groups/{groupId}
liveStreams/{streamId}
notifications/{notificationId}

Production uchun security rules, moderation, real-time presence va live/video transcoding alohida sozlanadi.
